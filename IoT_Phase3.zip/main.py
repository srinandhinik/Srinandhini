import time
import machine
import dht
import ujson
from umqtt.simple import MQTTClient

try:
    dht_sensor = dht.DHT22(machine.Pin(4)) 


    mqtt_broker = "your_mqtt_broker_address"
    mqtt_topic = "your_topic"
    mqtt_username = "your_username"
    mqtt_password = "your_password"
    mqtt_client_id = "your_client_id"


    client = MQTTClient(mqtt_client_id, mqtt_broker, user=mqtt_username, password=mqtt_password)


    client.connect()

    try:
      while True:
        try:
            
            dht_sensor.measure()
            temperature_c = dht_sensor.temperature()
            humidity = dht_sensor.humidity()

            
            data = {
                "temperature": temperature_c,
                "humidity": humidity
            }

            
            client.publish(mqtt_topic, ujson.dumps(data))

        except Exception as e:
            print("Error:", e)

        time.sleep(60)  

    except KeyboardInterrupt:
        pass


    client.disconnect()
except OSError as e:
    print("connected to wifi....")
    print("   data sent successfully")